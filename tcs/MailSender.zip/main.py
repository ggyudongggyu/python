from MailSender import MailSender

address = 'greed.gggg@gmail.com'
password = 'abcd@1234'
msender = MailSender(address, password)

#とりあえず自分のアドレス宛に送ってみる
msender.send(address, '/home/kaisyoku/workspace/kensyu/weekly_gift_shimizu.csv')
